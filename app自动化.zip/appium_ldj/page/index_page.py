'''
@author: liudongjie
@software: SeleniumTest
@file: index_page.py
@time: 2020/3/25 22:05
@desc:
'''

from page.base_page import BasePage
from appium.webdriver.common.mobileby import MobileBy as By

class IndexPage(BasePage):
    eat_button_locator = (By.XPATH,'//android.widget.LinearLayout[@resource-id=\"cn.missfresh.application:id/cv_main_bottom_tab_layout\"]/android.widget.FrameLayout[3]/android.widget.LinearLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.ImageView[1]')

    def eat_button_click(self):
        ''' 点击吃什么按钮 '''
        self.find_element(self.eat_button_locator).click()