'''
@author: liudongjie
@software: SeleniumTest
@file: search_result_page.py
@time: 2020/3/26 16:38
@desc:
'''

from page.base_page import BasePage
from appium.webdriver.common.mobileby import MobileBy as By

class SearchResultPage(BasePage):
    search_frame_locator = (By.XPATH,'//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/search_view\"]')
    first_dish_locator = (By.XPATH,'//android.widget.FrameLayout[1]'
                                   '/android.widget.LinearLayout[1]/'
                                   'android.widget.FrameLayout[1]/'
                                   'android.widget.LinearLayout[1]/'
                                   'android.widget.FrameLayout[1]/a'
                                   'ndroid.widget.FrameLayout[1]/an'
                                   'droid.view.View[1]/android.widge'
                                   't.FrameLayout[4]/android.support.v7.'
                                   'widget.RecyclerView[1]/android.widget.'
                                   'RelativeLayout[1]/android.widget.Relativ'
                                   'eLayout[1]/android.widget.TextView[1]')

    def search_frame_text(self):
        ''' 获取搜索框里的文本 '''
        return self.find_element(self.search_frame_locator).text

    def first_dish_text(self):
        ''' 获取第一个菜品的文本 '''
        return self.find_element(self.first_dish_locator).text