'''
@author: liudongjie
@software: SeleniumTest
@file: personal_page.py
@time: 2020/3/26 10:35
@desc:
'''

from page.base_page import BasePage
from appium.webdriver.common.mobileby import MobileBy as By

class PersonalPage(BasePage):

    four_dish_name_coordinate = (673,1216)
    collection_button_locator = (By.ANDROID_UIAUTOMATOR,'new UiSelector().textStartsWith("收藏")')

    def collection_button_click(self):
        self.find_element(self.collection_button_locator).click()

    def four_dish_name_coordinate_tap(self):
        self.driver.tap([self.four_dish_name_coordinate],300)






