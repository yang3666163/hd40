'''
@author: liudongjie
@software: SeleniumTest
@file: base_page.py
@time: 2020/3/25 21:59
@desc:
'''
class BasePage():

    def __init__(self,driver):
        self.driver = driver

    def find_element(self,locator):
        return self.driver.find_element(*locator)

    def find_elements(self,locator):
        return self.driver.find_elements(*locator)

