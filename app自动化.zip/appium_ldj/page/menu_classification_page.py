'''
@author: liudongjie
@software: SeleniumTest
@file: menu_classification_page.py
@time: 2020/3/25 22:58
@desc:
'''

from page.base_page import BasePage
from appium.webdriver.common.mobileby import MobileBy as By

class MenuClassificationPage(BasePage):
    vegetables_button_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/recycler_view\"]/android.widget.LinearLayout[6]/android.widget.ImageView[1]')
    popular_classification_locator = (By.XPATH,'//android.widget.TextView[@text=\"热门分类\"]')

    def vegetables_button_click(self):
        ''' 点击蔬菜按钮 '''
        self.find_element(self.vegetables_button_locator).click()

    def popular_classification_text(self):
        ''' 获取文本 '''
        return self.find_element(self.popular_classification_locator).text

