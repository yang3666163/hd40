'''
@author: liudongjie
@software: SeleniumTest
@file: eat_page.py
@time: 2020/3/25 21:59
@desc:
'''

from page.base_page import BasePage
from appium.webdriver.common.mobileby import MobileBy as By

class EatPage(BasePage):
    selected_dish_coordinate = (224,1062)
    first_dish_locator = (By.XPATH,'//android.widget.FrameLayout[1]/'
                                   'android.widget.LinearLayout[1]/android.widget.'
                                   'FrameLayout[1]/android.widget.LinearLayout[1]/a'
                                   'ndroid.widget.FrameLayout[1]/android.widget.Relat'
                                   'iveLayout[1]/android.widget.LinearLayout[1]/andr'
                                   'oid.widget.FrameLayout[1]/android.widget.LinearLay'
                                   'out[1]/android.widget.FrameLayout[1]/android.view.V'
                                   'iew[1]/android.view.View[1]/android.support.v7.widget.'
                                   'RecyclerView[1]/android.widget.RelativeLayout[1]/android.'
                                   'widget.RelativeLayout[1]/android.widget.TextView[1]')
    eat_search_click_locator = (By.XPATH,'//android.widget.EditText[@resource-id=\"cn.missfresh.application:id/et_search_input\"]')
    eat_search_send_locator = (By.XPATH,'//android.widget.EditText[@resource-id=\"cn.missfresh.application:id/search_view\"]')
    eat_search_button_locator = (By.XPATH,'//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/tv_search\"]')
    private_dishes_button_locator = (By.ANDROID_UIAUTOMATOR,'new UiSelector().textStartsWith("私房菜")')
    menu_classification_button_locator = (By.XPATH,'//android.widget.FrameLayout[@resource-id=\"cn.missfresh.application:id/fl_open_classify\"]')
    personal_button_locator = (By.XPATH,'//android.widget.ImageView[@resource-id=\"cn.missfresh.application:id/iv_user_avatar\"]')
    private_dishes_first_dish_locator = (By.XPATH,'//android.widget.FrameLayout[1]/'
                                                  'android.widget.LinearLayout[1]/'
                                                  'android.widget.FrameLayout[1]/'
                                                  'android.widget.LinearLayout[1]/'
                                                  'android.widget.FrameLayout[1]/'
                                                  'android.widget.RelativeLayout[1]/'
                                                  'android.widget.LinearLayout[1]/'
                                                  'android.widget.FrameLayout[1]/'
                                                  'android.widget.LinearLayout[1]/'
                                                  'android.widget.FrameLayout[1]/'
                                                  'android.view.View[1]/'
                                                  'android.view.View[1]/'
                                                  'android.support.v7.widget.RecyclerView[1]/'
                                                  'android.widget.RelativeLayout[1]/'
                                                  'android.widget.RelativeLayout[1]/'
                                                  'android.widget.TextView[1]')

    def private_dishes_first_dish_text(self):
        ''' 拿到私家菜第一个菜品的文本 '''
        return self.find_element(self.private_dishes_first_dish_locator).text

    def first_dish_text(self):
        ''' 拿到精选第一个菜品的文本 '''
        return self.find_element(self.first_dish_locator).text

    def personal_button_click(self):
        ''' 点击个人按钮 '''
        self.find_element(self.personal_button_locator).click()

    def menu_classification_button_click(self):
        ''' 点击菜谱分类按钮 '''
        self.find_element(self.menu_classification_button_locator).click()

    def private_dishes_button_click(self):
        ''' 点击私家菜按钮 '''
        self.find_element(self.private_dishes_button_locator).click()

    def selected_dish_coordinate_tap(self):
        ''' 点击精选第一个菜品 '''
        self.driver.tap([self.selected_dish_coordinate],500)

    def eat_search_click(self):
        ''' 点击搜索输入框 '''
        self.find_element(self.eat_search_click_locator).click()

    def eat_search_send(self,dishname):
        ''' 输入关键字到搜索输入框 '''
        self.find_element(self.eat_search_send_locator).send_keys(dishname)

    def eat_search_button_click(self):
        ''' 点击搜索按钮 '''
        self.find_element(self.eat_search_button_locator).click()


