'''
@author: liudongjie
@software: SeleniumTest
@file: base_page.py
@time: 2020/3/26 10:11
@desc:
'''

from page.base_page import BasePage
from appium.webdriver.common.mobileby import MobileBy as By

class DetailsPage(BasePage):
    give_the_thumbs_up_button_locator = (By.XPATH,'//android.widget.ImageView[@resource-id=\"cn.missfresh.application:id/iv_like\"]')
    collection_button_locator = (By.XPATH,'//android.widget.ImageView[@resource-id=\"cn.missfresh.application:id/iv_collect\"]')
    dish_name_locator = (By.XPATH,'//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/tv_recipes_title\"]')
    share_locator = (By.XPATH,'//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/tv_share\"]')

    def give_the_thumbs_up_button_click(self):
        ''' 点击点赞按钮 '''
        self.find_element(self.give_the_thumbs_up_button_locator).click()

    def share_text(self):
        ''' 获取分享文本 '''
        return self.find_element(self.share_locator).text

    def collection_button_click(self):
        ''' 点击收藏按钮 '''
        self.find_element(self.collection_button_locator).click()

    def dish_name_text(self):
        ''' 拿到菜品名 '''
        return self.find_element(self.dish_name_locator).text

    def return_button_click(self):
        ''' 返回上一页 '''
        self.driver.press_keycode('4')