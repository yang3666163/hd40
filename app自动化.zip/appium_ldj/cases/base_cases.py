'''
@author: liudongjie
@software: SeleniumTest
@file: base_cases.py
@time: 2020/3/25 21:55
@desc:
'''
import unittest
from common.driver import mryxapp
from time import sleep

class BaceCase(unittest.TestCase):
    def setUp(self):
        self.driver = mryxapp()
        sleep(5)

    def tearDown(self):
        self.driver.quit()