'''
@author: liudongjie
@software: SeleniumTest
@file: mryx_menu_details_.py
@time: 2020/3/25 16:40
@desc:
'''

import unittest
from time import sleep
from cases.base_cases import BaceCase
from page.index_page import IndexPage
from page.eat_page import EatPage
from page.details_page import DetailsPage
from common.logger import Logger
logger = Logger().logger


class MenuDetails(BaceCase):
    def test_menu_details(self):
        ip = IndexPage(self.driver)
        ip.eat_button_click() #进入到吃什么页面
        sleep(3)
        ep = EatPage(self.driver)
        ep.selected_dish_coordinate_tap() #进入第一项菜品
        sleep(3)
        #断言
        dp = DetailsPage(self.driver)
        text = dp.share_text()
        logger.info(text)
        self.assertEqual(text,"分享")

if __name__ == '__main__':
    unittest.main()
