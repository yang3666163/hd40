'''
@author: liudongjie
@software: SeleniumTest
@file: mryx_give_the_thumbs-up.py
@time: 2020/3/26 9:52
@desc:
'''

import unittest
from time import sleep
from cases.base_cases import BaceCase
from page.index_page import IndexPage
from page.eat_page import EatPage
from page.details_page import DetailsPage
from page.personal_page import PersonalPage
from common.logger import Logger
logger = Logger().logger


class GiveTheThumbasUp(BaceCase):
    def test_menu_details(self):
        ip = IndexPage(self.driver)
        ip.eat_button_click() #进入到吃什么页面
        sleep(3)
        ep = EatPage(self.driver)
        ep.selected_dish_coordinate_tap()  # 进入第一项菜品
        sleep(3)
        dp = DetailsPage(self.driver)
        dp.give_the_thumbs_up_button_click() #进行点赞
        dishname1 = dp.dish_name_text()
        logger.info(dishname1)
        sleep(3)
        # 断言
        dp.return_button_click() #返回
        sleep(3)
        ep.personal_button_click() #进入个人界面
        sleep(3)
        pp = PersonalPage(self.driver)
        pp.four_dish_name_coordinate_tap() #进入第四个菜品页面
        dishname2 = dp.dish_name_text()
        logger.info(dishname2)
        self.assertEqual(dishname1, dishname2)


if __name__ == '__main__':
    unittest.main()