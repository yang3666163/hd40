'''
@author: liudongjie
@software: SeleniumTest
@file: mryx_menu_classification.py
@time: 2020/3/25 22:51
@desc:
'''

import unittest
from time import sleep
from cases.base_cases import BaceCase
from page.index_page import IndexPage
from page.eat_page import EatPage
from page.menu_classification_page import MenuClassificationPage
from common.logger import Logger
logger = Logger().logger


class MenuClassification(BaceCase):
    def test_menu_details(self):
        ip = IndexPage(self.driver)
        ip.eat_button_click() #进入到吃什么页面
        sleep(3)
        ep = EatPage(self.driver)
        ep.menu_classification_button_click() #进入菜谱分类界面
        sleep(3)
        #断言
        mcp = MenuClassificationPage(self.driver)
        classificationname = mcp.popular_classification_text()
        logger.info(classificationname)
        self.assertEqual(classificationname,'热门分类')


if __name__ == '__main__':
    unittest.main()
