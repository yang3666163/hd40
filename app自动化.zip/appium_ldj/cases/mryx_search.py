'''
@author: liudongjie
@software: SeleniumTest
@file: mryx_search.py
@time: 2020/3/25 15:22
@desc:
'''

import unittest
from time import sleep
from cases.base_cases import BaceCase
from page.index_page import IndexPage
from page.eat_page import EatPage
from page.search_result_page import SearchResultPage
from common.logger import Logger
logger = Logger().logger

class Search(BaceCase):

    def test_search(self):
        dishname = "鸡蛋"
        ip = IndexPage(self.driver)
        ip.eat_button_click() #进入到吃什么页面
        sleep(3)
        ep = EatPage(self.driver)
        ep.eat_search_click()
        sleep(3)
        ep.eat_search_send(dishname)
        sleep(3)
        ep.eat_search_button_click()
        #断言
        srp = SearchResultPage(self.driver)
        searchresult = srp.search_frame_text()
        logger.info(searchresult)
        self.assertEqual(searchresult, '鸡蛋')



if __name__ == '__main__':
    unittest.main()

