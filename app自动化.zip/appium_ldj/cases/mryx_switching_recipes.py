'''
@author: liudongjie
@software: SeleniumTest
@file: mryx_screen_slide.py
@time: 2020/3/25 16:52
@desc:
'''

import unittest
from time import sleep
from cases.base_cases import BaceCase
from page.index_page import IndexPage
from page.eat_page import EatPage
from common.logger import Logger
logger = Logger().logger

class SwitchingRecipes(BaceCase):

    def test_search(self):
        ip = IndexPage(self.driver)
        ip.eat_button_click() #进入到吃什么页面
        sleep(3)
        ep = EatPage(self.driver)
        dishname1 = ep.first_dish_text()
        logger.info(dishname1)
        sleep(3)
        ep.private_dishes_button_click()
        sleep(3)
        dishname2 = ep.private_dishes_first_dish_text()
        logger.info(dishname2)
        #断言
        self.assertNotEqual(dishname1,dishname2)


if __name__ == '__main__':
    unittest.main()