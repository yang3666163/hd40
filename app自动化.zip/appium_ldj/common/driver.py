'''
@author: liudongjie
@software: SeleniumTest
@file: driver.py
@time: 2020/3/25 21:52
@desc:
'''

from appium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def mryxapp():
    desired_capabilities = {
        'platformName': 'Android',
        'deviceName': '127.0.0.1:62001',
        'plaformVersion': '5.1.1',
        'appPackage': 'cn.missfresh.application',
        'appActivity': 'cn.missfresh.module.base.main.view.SplashActivity',
        'noReset': True,
        'automatorName':'Uiautomator2'
    }

    driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_capabilities)

    return driver