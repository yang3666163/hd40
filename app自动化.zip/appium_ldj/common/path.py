'''
@author: liudongjie
@software: SeleniumTest
@file: path.py
@time: 2020/3/26 23:30
@desc:
'''

from pathlib import Path
''' 设置文件的路径 '''
BASE_PATH = Path(__file__).absolute().parent.parent
p = Path(BASE_PATH)
CASE_PATH = p.joinpath("cases")
DATA_PATH = p.joinpath("datas")
COMMON_PATH = p.joinpath("common")
PAGE_PATH = p.joinpath("page")
LOG_PATH = p.joinpath("log")