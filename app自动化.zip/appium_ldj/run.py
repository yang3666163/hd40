'''
@author: liudongjie
@software: SeleniumTest
@file: run.py.py
@time: 2020/3/26 23:27
@desc:
'''

import unittest
from BeautifulReport import BeautifulReport
import time
from common.path import *
#执行所有测试用例，并生成测试报告
discover = unittest.defaultTestLoader.discover(CASE_PATH,pattern='mryx*.py')#设置用例的执行范围
time_format = time.strftime("%Y-%m-%d %H_%M_%S")#格式化时间
report_file_name = "mryx_{}.html".format(time_format)#设置报告文件名称
BeautifulReport(discover).report(description="每日优鲜APP购物车测试用例",
                                 report_dir='report',
                                 filename=report_file_name)#执行用例并设定报告名称