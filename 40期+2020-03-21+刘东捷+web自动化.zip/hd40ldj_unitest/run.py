import os
import unittest
import time
from common.path import *
from page.login_page import LoginPage
from common.driver import chrome
from common.util import create_cookie
from BeautifulReport import BeautifulReport


try:
    lp = LoginPage(chrome())
    lp.open()
    lp.login("admin","123456") #登录成功
    cookies = lp.get_cookies() #获取登录的cookie
    print(cookies)
    cookies = create_cookie(cookies[0]) #获取cookie中的name和value
    print(cookies)
    file_name = os.path.join(DATA_PATH,'cookies.ini')
    with open(file_name,"w",encoding="utf-8") as f:
        f.write(str(cookies))

except Exception as e:
    raise
finally:
    lp.driver.quit()

discover = unittest.defaultTestLoader.discover(CASE_PATH,pattern="crm*.py") #设置用例执行的范围
time_format = time.strftime("%Y-%m-%d %H_%M_%S") #设置时间格式
report_file_name = ("crm_%r.html" %(time_format))
BeautifulReport(discover).report(description="CRM项目测试用例",report_dir="report",filename=report_file_name) #执行用例并设置用例报告的名称