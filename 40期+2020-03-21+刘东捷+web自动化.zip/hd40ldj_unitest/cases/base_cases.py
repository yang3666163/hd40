'''
@author: liudongjie
@software: SeleniumTest
@file: crm_add_customercare.py
@time: 2020-03-17 20:00
@desc:
'''

import unittest
from common.driver import chrome
from common.util import get_cookie
from common.path import *

class BaseCase(unittest.TestCase):
    def setUp(self):
        self.driver = chrome()
        self.driver.get(HOST)
        self.driver.add_cookie(get_cookie("cookies.ini"))

    def tearDown(self):
        self.driver.quit()

