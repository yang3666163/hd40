'''
@author: liudongjie
@software: SeleniumTest
@file: crm_add_customercare.py
@time: 2020-03-17 20:00
@desc: ClueAddTast
'''

import unittest
import ddt
from common.util import get_data_from_csv
from cases.base_cases import BaseCase
from page.clue_page import CluePage
from page.index_page import IndexPage
from page.login_page import LoginPage
from page.clue_task_page import ClueTaskPage
from page.clue_details_page import ClueDetailsPage
from page.add_clue_task_page import AddClueTaskPage
from time import sleep
from common.logger import Logger
from common.path import *
logger = Logger().logger

@ddt.ddt
class ClueAddTast(BaseCase):

    @ddt.data(*get_data_from_csv("clue_tast.csv"))
    @ddt.unpack
    def test_clue_add_tast(self,username,password,theme,send_message,time,state,priority,describe):
        url = CLUE_PATH

        lp = LoginPage(self.driver,url)
        lp.open()
        # lp.login(username, password)  # 登入成功进入主页面
        # ip = IndexPage(self.driver)
        # ip.clue_button_click()  # 登入成功进入线索界面
        cp = CluePage(self.driver)
        cp.table_tbody_operation_See_click()  # 进入第一个线索的详情页
        cdp = ClueDetailsPage(self.driver)
        cdp.task_click() #进入到线索任务界面
        sleep(3)
        ctp = ClueTaskPage(self.driver)
        ctp.add_task_button_click() #进入到线索添加界面
        sleep(3)
        actp = AddClueTaskPage(self.driver)
        actp.theme_send(theme) #输入主题
        actp.table_send_message(send_message)
        sleep(3)
        actp.person_in_charge_click()
        sleep(3)
        actp.person_in_charge_choice_click()
        actp.person_in_charge_ok_button_click() #选择负责人
        actp.task_related_person_click()
        sleep(3)
        actp.task_related_person_choice_click()
        actp.task_related_person_ok_button_click() #选择任务相关人
        sleep(3)
        actp.due_date_send(time)
        actp.state_select_choice(state)
        actp.priority_select_choice(priority)
        actp.describe_send(describe)
        actp.save_task_button_click() #点击添加任务按钮
        #断言
        cdp.task_click()
        sleep(3)
        logger.info(ctp.task_table())
        logger.info(theme)
        self.assertEqual(ctp.task_table(),theme)



if __name__ == '__main__':
    unittest.main()

