'''
@author: liudongjie
@software: SeleniumTest
@file: crm_receive_clue.py
@time: 2020/3/20 1:34
@desc:
'''

import unittest
import ddt
from cases.base_cases import BaseCase
from page.clue_page import CluePage
from page.login_page import LoginPage
from page.clue_pool_page import CluePoolPage
from common.util import get_data_from_csv
from time import sleep
from common.logger import Logger
from common.path import *
logger = Logger().logger

@ddt.ddt
class ReceiveClue(BaseCase):

    @ddt.data(*get_data_from_csv("user.csv"))
    @ddt.unpack
    def test_receive_clue(self,username,password):
        url = CLUE_PATH

        lp = LoginPage(self.driver,url)
        lp.open()
        # lp.login(username, password)  # 登入成功进入主页面
        # ip = IndexPage(self.driver)
        # ip.clue_button_click()  # 进入到线索界面
        cp = CluePage(self.driver)
        cp.clue_pool_button_click()  # 进入到线索池界面
        cpp = CluePoolPage(self.driver)
        old_number = cpp.table_tbody_len()
        cpp.table_tbody_operation_receive_click(1)
        sleep(4)
        #断言
        new_number = cpp.table_tbody_len()
        logger.info(new_number)
        logger.info(old_number)
        self.assertEqual(old_number-1,new_number)


if __name__ == '__main__':
    unittest.main()


