'''
@author: liudongjie
@software: SeleniumTest
@file: crm_add_customercare.py
@time: 2020-03-17 20:00
@desc: AddCustomercare
'''

import unittest
import ddt
from cases.base_cases import BaseCase
from common.util import get_data_from_csv
from page.login_page import LoginPage
from page.add_customercare_page import AddCustomerCarePage
from page.customercare_page import CustomerCarePage
from common.logger import Logger
from common.path import *
logger = Logger().logger

@ddt.ddt
class AddCustomercare(BaseCase):

    @ddt.data(*get_data_from_csv("customercare.csv"))
    @ddt.unpack
    def test_add_customercare(self,username,password,theme,time):
        url = CUSTOMERCARE_PATH

        lp = LoginPage(self.driver,url)
        lp.open()
        # lp.login(username,password) #登入成功进入主页面
        # ip = IndexPage(self.driver)
        # ip.customer_button_click() #进入到客户界面
        # cp = CustomerPage(self.driver)
        # cp.customercare_button_click() #进入到客户关怀界面
        ccp = CustomerCarePage(self.driver)
        ccp.add_customercare_button_click() #进入到添加客户关怀界面
        accp = AddCustomerCarePage(self.driver)
        accp.send_caring_theme(theme)
        accp.send_care_time(time)
        accp.save_button_click() #点击保存客户关怀按钮
        #断言
        caredate = ccp.table_tbody(1)
        logger.info(caredate)
        logger.info(time)
        self.assertEqual(caredate,time[0:10])





if __name__ == '__main__':
    unittest.main()