'''
@author: liudongjie
@software: SeleniumTest
@file: crm_add_customercare.py
@time: 2020-03-17 20:00
@desc: AddClue
'''

import unittest
import ddt
from common.path import *
from common.util import get_data_from_csv
from cases.base_cases import BaseCase
from page.clue_page import CluePage
from page.login_page import LoginPage
from page.add_clue_page import AddCluePage
from common.logger import Logger
logger = Logger().logger

@ddt.ddt
class AddClue(BaseCase):

    @ddt.data(*get_data_from_csv("cliu.csv"))
    @ddt.unpack
    def test_add_clue(self,username,password,contactsname):
        url = CLUE_PATH

        lp = LoginPage(self.driver,url)
        lp.open()
        # lp.login(username,password) #登入成功进入主页面
        # ip = IndexPage(self.driver)
        # ip.clue_button_click() #登入成功进入线索界面
        cp = CluePage(self.driver)
        cp.add_clue_button_click() #进入添加线索界面
        acp = AddCluePage(self.driver)
        acp.contacts_name_send(contactsname)
        acp.save_button_click() #点击保存线索按钮
        #断言
        contacts_name = cp.table_tbody_contacts_name(1)
        logger.info(contactsname)
        logger.info(contacts_name)
        self.assertEqual(contacts_name,contactsname)

if __name__ == '__main__':
    unittest.main()