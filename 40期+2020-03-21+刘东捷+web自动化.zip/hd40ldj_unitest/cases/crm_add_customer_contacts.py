'''
@author: liudongjie
@software: SeleniumTest
@file: crm_add_contacts.py
@time: 2020/3/19 23:45
@desc:
'''

import unittest
import ddt
from common.util import get_data_from_csv
from cases.base_cases import BaseCase
from page.customer_page import CustomerPage
from page.login_page import LoginPage
from page.customer_contacts_page import CustomerContactsPage
from page.add_customer_contacts_page import AddCustomerContactsPage
from time import sleep
from common.logger import Logger
from common.path import *
logger = Logger().logger

@ddt.ddt
class test_add_customer_contacts(BaseCase):

    @ddt.data(*get_data_from_csv("customer_contacts.csv"))
    @ddt.unpack
    def test_add_customer(self,username,password,name,saltname,position,telephone,mail,qq,zipcode,address,remarks):
        url = CUSTOMER_CONTACTS_PATH

        lp = LoginPage(self.driver,url)
        lp.open()
        # lp.login(username,password) #登入成功进入主页面
        # ip = IndexPage(self.driver)
        # ip.customer_button_click() #进入到客户界面
        # cp = CustomerPage(self.driver)
        # cp.contacts_button_click() #进入到联系人界面
        ccp = CustomerContactsPage(self.driver)
        ccp.add_contacts_button_click() #进入到添加联系人界面
        sleep(3)
        accp = AddCustomerContactsPage(self.driver)
        accp.name_send(name)
        accp.salt_name_send(saltname)
        accp.subordinate_customer_name_send_click()
        sleep(3)
        accp.subordinate_customer_table_tbody_click()
        sleep(3)
        accp.subordinate_customer_ok_button_click()
        accp.position_send(position)
        accp.telephone_send(telephone)
        accp.mail_send(mail)
        accp.qq_send(qq)
        accp.zip_code_send(zipcode)
        accp.contact_address_send(address)
        accp.remarks_send(remarks)
        accp.contacts_save_button_click() #点击保存客户联系人按钮
        #断言
        contactsname = ccp.customer_contacts_table_tbody_text(1,2)
        logger.info(contactsname)
        logger.info(name)
        self.assertEqual(contactsname,name)


if __name__ == '__main__':
    unittest.main()





