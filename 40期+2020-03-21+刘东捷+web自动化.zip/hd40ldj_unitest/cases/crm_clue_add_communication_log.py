'''
@author: liudongjie
@software: SeleniumTest
@file: crm_add_customercare.py
@time: 2020-03-17 20:00
@desc: ClueAddCommunicationeLog
'''

import unittest
import ddt
from cases.base_cases import BaseCase
from page.clue_page import CluePage
from common.util import get_data_from_csv
from page.index_page import IndexPage
from page.login_page import LoginPage
from page.clue_details_page import ClueDetailsPage
from page.clue_communication_log_page import ClueCommunicationLogPage
from page.add_clue_communication_log_page import AddClueCommunicationLogPage
from time import sleep
from common.logger import Logger
from common.path import *
logger = Logger().logger

@ddt.ddt
class ClueAddCommunicationeLog(BaseCase):

    @ddt.data(*get_data_from_csv("clue_communicatione_log.csv"))
    @ddt.unpack
    def test_clue_add_communicatione_log(self,username,password,title,content,time,nextcontent):
        url = CLUE_PATH

        lp = LoginPage(self.driver,url)
        lp.open()
        # lp.login(username,password) #登入成功进入主页面
        # ip = IndexPage(self.driver)
        # ip.clue_button_click() #登入成功进入线索界面
        cp = CluePage(self.driver)
        cp.table_tbody_operation_See_click() #进入第一个线索的详情页
        cdp = ClueDetailsPage(self.driver)
        cdp.communication_log_click() #进入线索沟通日志界面
        sleep(3)
        cclp = ClueCommunicationLogPage(self.driver)
        cclp.add_clue_communication_log_button_click() #进入添加线索沟通日志界面
        sleep(3)
        acclp = AddClueCommunicationLogPage(self.driver)
        acclp.title_send(title)
        acclp.content_send(content)
        acclp.next_contact_time_send(time)
        acclp.next_contact_content_send(nextcontent)
        acclp.add_to_communication_log_button_click() #点击保存沟通日志按钮
        #断言
        ip = IndexPage(self.driver)
        ip.clue_button_click()
        next_content = cp.table_tbody_next_contact_content()
        logger.info(next_content)
        logger.info(nextcontent)
        self.assertEqual(next_content,nextcontent)




if __name__ == '__main__':
    unittest.main()