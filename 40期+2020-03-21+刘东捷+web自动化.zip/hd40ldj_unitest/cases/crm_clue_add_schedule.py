'''
@author: liudongjie
@software: SeleniumTest
@file: crm_add_customercare.py
@time: 2020-03-17 20:00
@desc: ClueAddSchedule
'''

import unittest
import ddt
from cases.base_cases import BaseCase
from page.clue_page import CluePage
from page.index_page import IndexPage
from page.login_page import LoginPage
from common.util import get_data_from_csv
from page.clue_details_page import ClueDetailsPage
from page.clue_schedule_page import ClueSchedulePage
from page.add_clue_schedule_page import AddClueSchedulePage
from time import sleep
from common.logger import Logger
from common.path import *
logger = Logger().logger

@ddt.ddt
class ClueAddSchedule(BaseCase):

    @ddt.data(*get_data_from_csv("clue_schedule.csv"))
    @ddt.unpack
    def test_clue_add_schedule(self,username,password,theme,charge,place,starttime,endtime,describe):
        url = CLUE_PATH

        lp = LoginPage(self.driver,url)
        lp.open()
        # lp.login(username, password)  # 登入成功进入主页面
        # ip = IndexPage(self.driver)
        # ip.clue_button_click()  # 登入成功进入线索界面
        cp = CluePage(self.driver)
        cp.table_tbody_operation_See_click()  # 进入第一个线索的详情页
        cdp = ClueDetailsPage(self.driver)
        cdp.schedule_click() #进入到日程界面
        sleep(3)
        csp = ClueSchedulePage(self.driver)
        csp.add_schedule_button_click() #进入到添加日程界面
        sleep(3)
        acsp = AddClueSchedulePage(self.driver)
        acsp.schedule_theme_send(theme)
        acsp.schedule_person_in_charge_click()
        sleep(2)
        acsp.schedule_person_in_charge_table_click(charge)
        acsp.schedule_person_in_charge_table_ok_button_click()
        sleep(2)
        acsp.schedule_place_send(place)
        acsp.schedule_start_time_send(starttime)
        acsp.schedule_end_time_send(endtime)
        acsp.schedule_describe_send(describe)
        acsp.save_schedule_button_click() #点击保存日程按钮
        # 断言
        cdp.schedule_click()
        sleep(3)
        logger.info(csp.schedule_table())
        logger.info(theme)
        self.assertEqual(csp.schedule_table(), theme)

if __name__ == '__main__':
    unittest.main()