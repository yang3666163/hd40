'''
@author: liudongjie
@software: SeleniumTest
@file: crm_add_customercare.py
@time: 2020-03-17 20:00
@desc: CrmLogin
'''

import unittest
import ddt
from page.login_page import LoginPage
from page.index_page import IndexPage
from common.util import get_data_from_csv
from common.logger import Logger
from common.driver import chrome
from common.path import *
logger = Logger().logger


@ddt.ddt
class CrmLogin(unittest.TestCase):

    def setUp(self):
        self.driver = chrome()
        self.driver.get(CRM_PATH)

    @ddt.data(*get_data_from_csv("user.csv"))
    @ddt.unpack
    def test_Login(self, username, password):

        lp = LoginPage(self.driver)
        lp.login_username(username) #输入用户名
        lp.login_password(password) #输入密码
        lp.login_button() #点击登录
        ip = IndexPage(self.driver)
        #断言
        name = ip.get_username()
        logger.info(username)
        logger.info(name)
        self.assertEqual(username, name)

    def tearDown(self):
        self.driver.quit()


if __name__ == '__main__':
    unittest.main()
