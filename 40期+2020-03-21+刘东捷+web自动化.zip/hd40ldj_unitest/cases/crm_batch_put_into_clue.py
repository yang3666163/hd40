'''
@author: liudongjie
@software: SeleniumTest
@file: crm_add_customercare.py
@time: 2020-03-17 20:00
@desc: BatchPutIntoClue
'''

import unittest
import ddt
from cases.base_cases import BaseCase
from common.util import get_data_from_csv
from page.clue_page import CluePage
from page.index_page import IndexPage
from page.login_page import LoginPage
from page.clue_pool_page import CluePoolPage
from common.logger import Logger
from common.path import *
logger = Logger().logger

@ddt.ddt
class BatchPutIntoClue(BaseCase):

    @ddt.data(*get_data_from_csv("user.csv"))
    @ddt.unpack
    def test_batch_put_into_clue(self,username,password):
        url = CLUE_PATH

        lp = LoginPage(self.driver,url)
        lp.open()
        # lp.login(username,password) #登入成功进入主页面
        cp = CluePage(self.driver)
        cp.clue_pool_button_click() #进入到线索池界面
        cpp = CluePoolPage(self.driver)
        old_num = cpp.table_tbody_len() #获取原本线索池的线索数量
        ip = IndexPage(self.driver)
        ip.clue_button_click()  # 进入到线索界面
        cp.table_tbody_click() #多选随机项
        cp.batch_operation_click()
        cp.batch_put_into_clue_pool_click() #把选定的项放入线索池
        cp.alert_accept() #提示框点击确定

        #断言
        cp.clue_pool_button_click()
        cpp = CluePoolPage(self.driver)
        new_num = cpp.table_tbody_len()
        logger.info(old_num)
        logger.info(new_num)
        self.assertEqual(old_num+3,new_num)


if __name__ == '__main__':
    unittest.main()