'''
@author: liudongjie
@software: SeleniumTest
@file: crm_add_customercare.py
@time: 2020-03-17 20:00
@desc: AddCustomer
'''

import unittest
import ddt
from common.util import get_data_from_csv
from cases.base_cases import BaseCase
from page.customer_page import CustomerPage
from page.add_customer_page import AddCustomerPage
from page.login_page import LoginPage
from common.logger import Logger
from common.path import *
logger = Logger().logger

@ddt.ddt
class AddCustomer(BaseCase):

    @ddt.data(*get_data_from_csv("customer.csv"))
    @ddt.unpack
    def test_add_customer(self,username,password,name):
        url = CUSTOMER_PATH

        lp = LoginPage(self.driver,url)
        lp.open()
        # lp.login(username,password) #登入成功进入主页面
        # ip = IndexPage(self.driver)
        # ip.customer_button_click() #进入到客户界面
        cp = CustomerPage(self.driver)
        cp.add_customer_button_click() #进入到添加客户界面
        acp = AddCustomerPage(self.driver)
        acp.send_customer_name(name)
        acp.save_button_click() #点击保存客户按钮
        #断言
        customername = cp.table_tbody(1)
        logger.info(customername)
        logger.info(name)
        self.assertEqual(customername,name)



if __name__ == '__main__':
    unittest.main()



