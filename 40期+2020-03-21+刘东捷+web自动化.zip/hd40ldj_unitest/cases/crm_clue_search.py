'''
@author: liudongjie
@software: SeleniumTest
@file: crm_add_customercare.py
@time: 2020-03-17 20:00
@desc: Addcustomer
'''

import unittest
import ddt
from cases.base_cases import BaseCase
from page.clue_page import CluePage
from page.login_page import LoginPage
from common.util import get_data_from_csv
from common.logger import Logger
from common.path import *
logger = Logger().logger

@ddt.ddt
class Addcustomer(BaseCase):

    @ddt.data(*get_data_from_csv("clue_search.csv"))
    @ddt.unpack
    def test_add_customer(self,username,password,choice,keyword):
        url = CLUE_PATH

        lp = LoginPage(self.driver,url)
        lp.open()
        # lp.login(username,password) #登入成功进入主页面
        # ip = IndexPage(self.driver)
        # ip.clue_button_click() #登入成功进入线索界面
        cp = CluePage(self.driver)
        cp.filter_select_choice(choice) #选择筛选条件
        cp.clue_search_send(keyword) #输入关键字
        cp.clue_search_button_click() #点击搜索
        #断言
        company_name = cp.table_tbody_company_name()
        logger.info(keyword)
        logger.info(company_name)
        self.assertIn(keyword,company_name)


if __name__ == '__main__':
    unittest.main()
