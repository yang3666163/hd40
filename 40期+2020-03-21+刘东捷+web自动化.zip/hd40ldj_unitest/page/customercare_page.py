from page.base_page import BasePage
from selenium.webdriver.common.by import By

class CustomerCarePage(BasePage):
    add_customercare_locator = (By.XPATH,'/html/body/div[5]/div[2]/div[1]/div/a/i')
    table_tbody_locator = (By.XPATH, '//*[@id="form1"]/table/tbody')

    def add_customercare_button_click(self):
        ''' 进入添加客户关怀界面 '''
        self.find_element(self.add_customercare_locator).click()

    def table_tbody(self,row):
        ''' 拿到列表第一行第四列的文本内容 '''
        tbody = self.find_element(self.table_tbody_locator)
        tr_list = tbody.find_elements(By.TAG_NAME,'tr')
        return tr_list[row-1].find_elements(By.TAG_NAME,'td')[3].text

