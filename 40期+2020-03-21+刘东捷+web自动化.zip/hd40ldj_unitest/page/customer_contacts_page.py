'''
@author: liudongjie
@software: SeleniumTest
@file: contacts_page.py
@time: 2020/3/19 23:15
@desc:
'''

from page.base_page import BasePage
from selenium.webdriver.common.by import By

class CustomerContactsPage(BasePage):
    add_contacts_button_locator = (By.XPATH,'/html/body/div[5]/div[2]/div[1]/div/a/i')
    customer_contacts_table_tbody_locator = (By.XPATH,'//*[@id="form1"]/table/tbody')

    def add_contacts_button_click(self):
        ''' 点击添加联系人按钮 '''
        self.find_element(self.add_contacts_button_locator).click()

    def customer_contacts_table_tbody_text(self,row,cell):
        ''' 获取索引位置的文本 '''
        tbody = self.find_element(self.customer_contacts_table_tbody_locator)
        tr_list = tbody.find_elements(By.TAG_NAME,'tr')
        return tr_list[row-1].find_elements(By.TAG_NAME,'td')[cell-1].text

