from page.base_page import BasePage
from selenium.webdriver.common.by import By

class AddClueSchedulePage(BasePage):
    schedule_theme_send_locator = (By.ID,'subject')
    schedule_person_in_charge_locator = (By.ID,'event_owner_name')
    schedule_person_in_charge_table_locator = (By.ID,'d_content')
    schedule_person_in_charge_table_ok_button_locator = (By.XPATH,'/html/body/div[15]/div[3]/div/button[1]/span')
    schedule_place_send_locator = (By.XPATH,'//*[@id="dialog-event"]/form/table/tbody[2]/tr[3]/td[4]/input')
    schedule_start_time_send_locator = (By.ID,'start_date')
    schedule_end_time_send_locator = (By.ID,'end_date')
    schedule_describe_send_locator = (By.XPATH,'//*[@id="dialog-event"]/form/table/tbody[2]/tr[5]/td[2]/textarea')
    save_schedule_button_locator = (By.XPATH,'//*[@id="dialog-event"]/form/table/tfoot/tr/td[2]/input[1]')

    def schedule_theme_send(self,theme):
        ''' 输入日程主题 '''
        self.find_element(self.schedule_theme_send_locator).send_keys(theme)

    def schedule_person_in_charge_click(self):
        ''' 点击负责人输入框 '''
        self.find_element(self.schedule_person_in_charge_locator).click()

    def schedule_person_in_charge_table_click(self,charge):
        ''' 选择负责人并选定他 '''
        tbody = self.find_element(self.schedule_person_in_charge_table_locator)
        tr_list = tbody.find_elements(By.TAG_NAME,"tr")
        for tr in tr_list:
            td_list = tr.find_elements(By.TAG_NAME,"td")
            if td_list[1].text == charge:
                td_list[0].find_element(By.TAG_NAME,"input").click()

    def schedule_place_send(self,place):
        ''' 地点输入 '''
        self.find_element(self.schedule_place_send_locator).send_keys(place)

    def schedule_person_in_charge_table_ok_button_click(self):
        ''' 选定负责人后点击OK按钮 '''
        self.find_element(self.schedule_person_in_charge_table_ok_button_locator).click()

    def schedule_start_time_send(self,starttime):
        ''' 输入日程开始时间 '''
        self.find_element(self.schedule_start_time_send_locator).send_keys(starttime)

    def schedule_end_time_send(self,endtime):
        ''' 输入日程结束时间 '''
        self.find_element(self.schedule_end_time_send_locator).send_keys(endtime)

    def schedule_describe_send(self,describe):
        ''' 输入日程描述 '''
        self.find_element(self.schedule_describe_send_locator).send_keys(describe)

    def save_schedule_button_click(self):
        ''' 保存日程按钮 '''
        self.find_element(self.save_schedule_button_locator).click()