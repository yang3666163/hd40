from page.base_page import BasePage
from selenium.webdriver.common.by import By

class ClueSchedulePage(BasePage):
    add_schedule_button_locator = (By.XPATH,'//*[@id="tab5"]/div/div[2]/a')
    schedule_table_tbody_locator = (By.XPATH,'//*[@id="tab5"]/table/tbody')

    def add_schedule_button_click(self):
        ''' 点击添加线索日程按钮 '''
        self.find_element(self.add_schedule_button_locator).click()

    def schedule_table(self):
        ''' 返回列表倒数最后一行第二列的文本内容 '''
        tbody = self.find_element(self.schedule_table_tbody_locator)
        tr_list = tbody.find_elements(By.TAG_NAME,'tr')
        td_list = tr_list[1].find_elements(By.TAG_NAME,'td')
        return td_list[1].text
