from page.base_page import BasePage
from selenium.webdriver.common.by import By

class ClueDetailsPage(BasePage):
    communication_log_locator = (By.XPATH,'//*[@id="left_list"]/li[3]/a')
    task_locator = (By.XPATH,'//*[@id="left_list"]/li[5]/a')
    schedule_locator = (By.XPATH,'//*[@id="left_list"]/li[6]/a')

    def communication_log_click(self):
        ''' 点击沟通日志导引 '''
        self.find_element(self.communication_log_locator).click()

    def task_click(self):
        ''' 点击任务导引 '''
        self.find_element(self.task_locator).click()

    def schedule_click(self):
        ''' 点击日程导引 '''
        self.find_element(self.schedule_locator).click()

