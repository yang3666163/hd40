from page.base_page import BasePage
from selenium.webdriver.common.by import By

class ClueCommunicationLogPage(BasePage):
    add_clue_communication_log_button_locator = (By.XPATH,'//*[@id="tab2"]/div[1]/div[2]/a')

    def add_clue_communication_log_button_click(self):
        ''' 添加客户沟通日志按钮 '''
        self.find_element(self.add_clue_communication_log_button_locator).click()

        