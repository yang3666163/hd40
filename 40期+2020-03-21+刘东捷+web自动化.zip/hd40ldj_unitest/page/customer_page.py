from page.base_page import BasePage
from selenium.webdriver.common.by import By

class CustomerPage(BasePage):
    add_customer_button_locator = (By.XPATH,'/html/body/div[5]/div[2]/div[1]/div/a')
    table_tbody_locator = (By.XPATH,'//*[@id="form1"]/table/tbody')
    customercare_button_locator = (By.XPATH,'/html/body/div[5]/div[1]/ul/li[4]/a')
    contacts_button_locator = (By.XPATH,'/html/body/div[5]/div[1]/ul/li[3]/a')

    def contacts_button_click(self):
        ''' 进入联系人界面 '''
        self.find_element(self.contacts_button_locator).click()

    def add_customer_button_click(self):
        ''' 进入添加客户界面按钮 '''
        self.find_element(self.add_customer_button_locator).click()

    def customercare_button_click(self):
        ''' 进入客户关怀界面按钮 '''
        self.find_element(self.customercare_button_locator).click()

    def get_text(self,locator):
        return self.find_element(locator).text

    def table_tbody(self,row):
        ''' 拿到表格第一行第三列的文本内容 '''
        tbody = self.find_element(self.table_tbody_locator)
        tr_list = tbody.find_elements(By.TAG_NAME,'tr')
        return tr_list[row-1].find_elements(By.TAG_NAME,'td')[2].text



