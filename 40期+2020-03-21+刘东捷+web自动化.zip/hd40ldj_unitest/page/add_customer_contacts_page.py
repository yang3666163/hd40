'''
@author: liudongjie
@software: SeleniumTest
@file: add_contacts_page.py
@time: 2020/3/19 23:18
@desc:
'''

from page.base_page import BasePage
from selenium.webdriver.common.by import By
import random

class AddCustomerContactsPage(BasePage):
    name_send_locator = (By.ID,'name')
    salt_name_send_locator = (By.ID,'saltname')
    subordinate_customer_name_send_locator = (By.ID,'customer_name')
    subordinate_customer_table_tbody_locator = (By.ID,'datas')
    subordinate_customer_ok_button_locator =(By.XPATH,'/html/body/div[7]/div[3]/div/button[1]/span')
    position_send_locator = (By.XPATH,'/html/body/div[5]/div[2]/div/form/table/tbody/tr[3]/td[4]/input')
    telephone_send_locator = (By.XPATH,'/html/body/div[5]/div[2]/div/form/table/tbody/tr[4]/td[2]/input')
    mail_send_locator = (By.XPATH,'/html/body/div[5]/div[2]/div/form/table/tbody/tr[4]/td[4]/input')
    qq_send_locator = (By.XPATH,'/html/body/div[5]/div[2]/div/form/table/tbody/tr[5]/td[2]/input')
    zip_code_send_locator = (By.XPATH,'/html/body/div[5]/div[2]/div/form/table/tbody/tr[5]/td[4]/input')
    contact_address_send_locator = (By.XPATH,'/html/body/div[5]/div[2]/div/form/table/tbody/tr[6]/td[2]/input')
    remarks_send_locator = (By.XPATH,'/html/body/div[5]/div[2]/div/form/table/tbody/tr[7]/td[2]/textarea')
    contacts_save_button_locator = (By.XPATH,'/html/body/div[5]/div[2]/div/form/table/tfoot/tr/td[2]/input[1]')

    def name_send(self,name):
        ''' 输入姓名 '''
        self.find_element(self.name_send_locator).send_keys(name)

    def salt_name_send(self,saltname):
        ''' 输入尊称 '''
        self.find_element(self.salt_name_send_locator).send_keys(saltname)

    def subordinate_customer_name_send_click(self):
        ''' 点击所属客户输入框 '''
        self.find_element(self.subordinate_customer_name_send_locator).click()

    def subordinate_customer_table_tbody_click(self):
        ''' 选择所属客户 '''
        tbody = self.find_element(self.subordinate_customer_table_tbody_locator)
        tr_list = tbody.find_elements(By.TAG_NAME,'tr')
        inputs = []
        for n in range(len(tr_list)-1):
            inputs.append(tr_list[n].find_element(By.TAG_NAME,'td').find_element(By.TAG_NAME,'input'))
        i = random.sample(inputs,1)
        i[0].click()

    def subordinate_customer_ok_button_click(self):
        ''' 确定所属客户 '''
        self.find_element(self.subordinate_customer_ok_button_locator).click()

    def position_send(self,position):
        ''' 输入职位 '''
        self.find_element(self.position_send_locator).send_keys(position)

    def telephone_send(self,telephone):
        ''' 输入电话 '''
        self.find_element(self.telephone_send_locator).send_keys(telephone)

    def mail_send(self,mail):
        ''' 输入邮箱 '''
        self.find_element(self.mail_send_locator).send_keys(mail)

    def qq_send(self,qq):
        ''' 输入qq '''
        self.find_element(self.qq_send_locator).send_keys(qq)

    def zip_code_send(self,zipcode):
        ''' 输入邮编 '''
        self.find_element(self.zip_code_send_locator).send_keys(zipcode)

    def contact_address_send(self,address):
        ''' 联系人地址 '''
        self.find_element(self.contact_address_send_locator).send_keys(address)

    def remarks_send(self,remarks):
        ''' 输入备注 '''
        self.find_element(self.remarks_send_locator).send_keys(remarks)

    def contacts_save_button_click(self):
        ''' 保存联系人 '''
        self.find_element(self.contacts_save_button_locator).click()







