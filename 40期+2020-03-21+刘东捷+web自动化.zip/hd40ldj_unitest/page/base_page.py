from selenium.webdriver.support.select import Select
from common.path import *

class BasePage():

    host = CRM_PATH

    def __init__(self, driver, url=host):
        self.driver = driver
        self.url = url

    def find_element(self,locator):
        return self.driver.find_element(*locator)

    def alert_accept(self):
        self.driver.switch_to.alert.accept()

    def select_choice(self,locator):
        return Select(self.driver.find_element(*locator))

    def open(self):
        self.driver.get(self.url)


