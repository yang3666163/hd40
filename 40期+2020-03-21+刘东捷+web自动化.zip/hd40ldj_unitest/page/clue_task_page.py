from page.base_page import BasePage
from selenium.webdriver.common.by import By

class ClueTaskPage(BasePage):
    add_task_button_locator = (By.XPATH,'//*[@id="tab4"]/div/div[2]/a')
    task_table_tbody_locator = (By.XPATH,'//*[@id="tab4"]/table/tbody')

    def add_task_button_click(self):
        ''' 点击添加任务按钮 '''
        self.find_element(self.add_task_button_locator).click()

    def task_table(self):
        ''' 拿到列表倒数一行第二列的文本内容 '''
        tbody = self.find_element(self.task_table_tbody_locator)
        tr_list = tbody.find_elements(By.TAG_NAME,'tr')
        td_list = tr_list[-1].find_elements(By.TAG_NAME,'td')
        return td_list[1].text