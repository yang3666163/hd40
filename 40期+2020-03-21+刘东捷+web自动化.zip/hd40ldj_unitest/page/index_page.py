from selenium.webdriver.common.by import By
from page.base_page import BasePage

class IndexPage(BasePage):
    username_locator = (By.CSS_SELECTOR,'body > div.navbar.navbar-inve'
                                        'rse.navbar-fixed-top > div > div > div.nav-collapse.collapse > ul.nav.pull-right > li:nth-child(6) > a')
    customer_button_locator = (By.XPATH,'/html/body/div[1]/div/div/div[2]/ul[1]/li[2]/a')
    clue_button_locator = (By.XPATH,'/html/body/div[1]/div/div/div[2]/ul[1]/li[1]/a')

    def get_username(self):
        ''' 拿到用户名称 '''
        return self.find_element(self.username_locator).text.strip()

    def customer_button_click(self):
        ''' 点击进入客户页面按钮 '''
        self.find_element(self.customer_button_locator).click()

    def clue_button_click(self):
        ''' 点击进入线索页面按钮 '''
        self.find_element(self.clue_button_locator).click()