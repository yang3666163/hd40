from page.base_page import BasePage
from selenium.webdriver.common.by import By

class AddCluePage(BasePage):
    contacts_name_send_locator = (By.ID,'contacts_name')
    save_button_locator = (By.XPATH,'//*[@id="form1"]/table/tfoot/tr/td/input[1]')

    def contacts_name_send(self,contactsname):
        ''' 联系人姓名输入 '''
        self.find_element(self.contacts_name_send_locator).send_keys(contactsname)

    def save_button_click(self):
        ''' 点击保存线索按钮 '''
        self.find_element(self.save_button_locator).click()