from page.base_page import BasePage
from selenium.webdriver.common.by import By

class AddClueCommunicationLogPage(BasePage):
    title_send_locator = (By.ID,'subject')
    content_send_locator = (By.XPATH,'//*[@id="dialog-log"]/form/table/tbody/tr[3]/td[2]/textarea')
    next_contact_time_send_locator = (By.ID,'nextstep_time')
    next_contact_content_send_locator = (By.ID,'nextstep')
    add_to_communication_log_button_locator = (By.XPATH,'//*[@id="dialog-log"]/form/table/tbody/tr[5]/td[2]/input[1]')

    def title_send(self,title):
        ''' 主题输入 '''
        self.find_element(self.title_send_locator).send_keys(title)

    def content_send(self,content):
        ''' 内容输入 '''
        self.find_element(self.content_send_locator).send_keys(content)

    def next_contact_time_send(self,time):
        ''' 下次联系时间 '''
        self.find_element(self.next_contact_time_send_locator).send_keys(time)

    def next_contact_content_send(self,nextcontent):
        ''' 下次联系内容 '''
        self.find_element(self.next_contact_content_send_locator).send_keys(nextcontent)

    def add_to_communication_log_button_click(self):
        ''' 添加沟通日志按钮 '''
        self.find_element(self.add_to_communication_log_button_locator).click()