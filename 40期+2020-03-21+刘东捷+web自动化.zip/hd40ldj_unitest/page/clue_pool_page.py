from page.base_page import BasePage
from selenium.webdriver.common.by import By

class CluePoolPage(BasePage):
    table_tbody_locator = (By.XPATH, '//*[@id="form1"]/table/tbody')
    table_locator = (By.XPATH,'//*[@id="form1"]/table')


    def table_tbody_len(self):
        ''' 拿到线索池列表的线索数量 '''
        table = self.find_element(self.table_locator)
        tbody = self.find_element(self.table_tbody_locator)
        try:
            table.find_element(By.TAG_NAME,'thead')
            tr_list = tbody.find_elements(By.TAG_NAME, "tr")
            num = len(tr_list)
        except Exception:
            num = 0
        finally: return num

    def table_tbody_operation_receive_click(self,row):
        ''' 单击列表row行的第10列的领取按钮 '''
        tbody = self.find_element(self.table_tbody_locator)
        tr_list = tbody.find_elements(By.TAG_NAME, "tr")
        tr_list[row-1].find_elements(By.TAG_NAME, "td")[9].find_elements(By.TAG_NAME, "a")[3].click()

