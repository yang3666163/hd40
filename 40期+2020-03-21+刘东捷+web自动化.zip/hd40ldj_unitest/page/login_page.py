from selenium.webdriver.common.by import By
from page.base_page import BasePage

class LoginPage(BasePage):

    username_locator = (By.NAME, "name")
    password_locator = (By.NAME, "password")
    button_locator = (By.NAME, "submit")

    def login_username(self,username):
        ''' 输入用户名 '''
        self.find_element(self.username_locator).send_keys(username)

    def login_password(self,password):
        ''' 输入密码 '''
        self.find_element(self.password_locator).send_keys(password)

    def login_button(self):
        ''' 点击登录按钮 '''
        self.find_element(self.button_locator).click()

    def login(self,username,password):
        ''' 合并登录函数 '''
        self.login_username(username)
        self.login_password(password)
        self.login_button()

    def get_cookies(self):
        return self.driver.get_cookies()