from page.base_page import BasePage
from selenium.webdriver.common.by import By

class AddCustomerPage(BasePage):
    customer_name_locator = (By.ID,'name')
    save_button_locator = (By.XPATH,'//*[@id="form1"]/table/tfoot/tr/td/input[1]')

    def send_customer_name(self, name):
        ''' 输入客户名字 '''
        self.find_element(self.customer_name_locator).send_keys(name)

    def save_button_click(self):
        ''' 保存客户按钮 '''
        self.find_element(self.save_button_locator).click()