from page.base_page import BasePage
from selenium.webdriver.common.by import By
import random
from selenium.webdriver.support.select import Select

class AddClueTaskPage(BasePage):
    theme_send_locator = (By.ID,'subject')
    person_in_charge_locator = (By.ID,'owner_name')
    person_in_charge_div_locator = (By.XPATH,'//*[@id="ta1"]')
    person_in_charge_ok_button_locator = (By.XPATH,'/html/body/div[15]/div[3]/div/button[1]/span')
    task_related_person_locator = (By.ID,'about_roles_name')
    task_related_person_div_locator = (By.XPATH,'//*[@id="ta1"]')
    task_related_person_ok_button_locator = (By.XPATH,'/html/body/div[16]/div[3]/div/button[1]/span')
    due_date_send_locator = (By.ID,'due_date')
    state_select_locator = (By.XPATH,'//*[@id="dialog-task"]/form/table/tbody/tr[6]/td[2]/select')
    priority_select_locator = (By.XPATH,'//*[@id="dialog-task"]/form/table/tbody/tr[6]/td[4]/select')
    describe_send_locator = (By.XPATH,'//*[@id="dialog-task"]/form/table/tbody/tr[7]/td[2]/textarea')
    save_task_button_locator = (By.XPATH,'//*[@id="dialog-task"]/form/table/tfoot/tr/td[2]/input[1]')
    table_tbody_locator = (By.XPATH,'//*[@id="dialog-task"]/form/table/tbody')

    def theme_send(self,theme):
        ''' 输入任务主题 '''
        self.find_element(self.theme_send_locator).send_keys(theme)

    def table_send_message(self,send_message):
        ''' 选择发送方式 '''
        tbody = self.find_element(self.table_tbody_locator)
        tr_list = tbody.find_elements(By.TAG_NAME,"tr")
        td_list = tr_list[1].find_elements(By.TAG_NAME,'td')
        input_list = td_list[3].find_elements(By.TAG_NAME,'input')
        if send_message == "站内信":
            input_list[0].click()
        if send_message == "邮件":
            input_list[1].click()

    def person_in_charge_click(self):
        ''' 点击负责人输入框 '''
        self.find_element(self.person_in_charge_locator).click()

    def person_in_charge_choice_click(self):
        ''' 随机点击两个负责人 '''
        div = self.find_element(self.person_in_charge_div_locator)
        input_list = div.find_elements(By.TAG_NAME,'input')
        inputs = random.sample(input_list[1:], 2)
        for n in inputs:
            n.click()

    def person_in_charge_ok_button_click(self):
        ''' 选定负责人点击OK '''
        self.find_element(self.person_in_charge_ok_button_locator).click()

    def task_related_person_click(self):
        ''' 点击任务相关输入框 '''
        self.find_element(self.task_related_person_locator).click()

    def task_related_person_choice_click(self):
        ''' 选定两个随机任务相关人 '''
        div = self.find_element(self.task_related_person_div_locator)
        input_list = div.find_elements(By.TAG_NAME, 'input')
        inputs = random.sample(input_list[1:], 2)
        for n in inputs:
           n.click()

    def task_related_person_ok_button_click(self):
        ''' 点击任务相关OK按钮 '''
        self.find_element(self.task_related_person_ok_button_locator).click()

    def due_date_send(self,time):
        ''' 输入到期日期 '''
        self.find_element(self.due_date_send_locator).send_keys(time)

    def state_select_choice(self,state):
        ''' 选一个状态 '''
        self.select_choice(self.state_select_locator).select_by_visible_text(state)

    def priority_select_choice(self,priority):
        ''' 选一个优先级 '''
        self.select_choice(self.priority_select_locator).select_by_visible_text(priority)

    def save_task_button_click(self):
        ''' 点击保存任务按钮 '''
        self.find_element(self.save_task_button_locator).click()

    def describe_send(self,describe):
        ''' 输入任务描述 '''
        self.find_element(self.describe_send_locator).send_keys(describe)




