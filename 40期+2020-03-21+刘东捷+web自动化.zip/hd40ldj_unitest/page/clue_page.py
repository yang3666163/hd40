from page.base_page import BasePage
from selenium.webdriver.common.by import By
import random

class CluePage(BasePage):
    table_tbody_locator = (By.XPATH,'//*[@id="form1"]/table/tbody')
    batch_operation_locator = (By.XPATH,'/html/body/div[5]/div[2]/div[1]/ul/li[1]/div/a')
    batch_put_into_clue_pool_locator = (By.XPATH,'//*[@id="remove"]')
    clue_pool_button_locator = (By.XPATH,'/html/body/div[5]/div[1]/ul/li[2]/a')
    filter_select_locator = (By.ID,'field')
    clue_search_send_locator = (By.ID,'search')
    clue_search_button_locator = (By.ID,'dosearch')
    add_clue_button_locator = (By.XPATH,'/html/body/div[5]/div[2]/div[1]/div/a')

    def table_tbody_next_contact_content(self):
        ''' 获取线索页面列表第1行的第7列的文本内容 '''
        tbody = self.find_element(self.table_tbody_locator)
        tr_list = tbody.find_elements(By.TAG_NAME, "tr")
        return tr_list[0].find_elements(By.TAG_NAME, 'td')[6].text

    def table_tbody_operation_See_click(self):
        ''' 点击线索页面列表的第1行的最后1列中的查看按钮 '''
        tbody = self.find_element(self.table_tbody_locator)
        tr_list = tbody.find_elements(By.TAG_NAME, "tr")
        return tr_list[0].find_elements(By.TAG_NAME, 'td')[11].find_elements(By.TAG_NAME, 'a')[0].click()

    def table_tbody_contacts_name(self,row):
        ''' 点击线索页面列表的第1行的第3列中的文本内容 '''
        tbody = self.find_element(self.table_tbody_locator)
        tr_list = tbody.find_elements(By.TAG_NAME, "tr")
        return tr_list[row-1].find_elements(By.TAG_NAME, 'td')[2].text

    def table_tbody_company_name(self):
        ''' 点击线索页面列表的第1行的第2列中的文本内容 '''
        tbody = self.find_element(self.table_tbody_locator)
        tr_list = tbody.find_elements(By.TAG_NAME,"tr")
        return tr_list[0].find_elements(By.TAG_NAME, 'td')[1].text

    def table_tbody_click(self):
        ''' 随机点列表的3个线索 '''
        tbody = self.find_element(self.table_tbody_locator)
        input_list = tbody.find_elements(By.TAG_NAME,'input')
        inputs = random.sample(input_list,3)
        for n in inputs:
            n.click()
        # tr_list = tbody.find_elements(By.TAG_NAME,'tr')
        # tr_list[0].find_elements(By.TAG_NAME, 'td')[11].find_elements(By.TAG_NAME, 'input')[0].click()







    def batch_operation_click(self):
        ''' 批量操作按钮 '''
        self.find_element(self.batch_operation_locator).click()

    def batch_put_into_clue_pool_click(self):
        ''' 批量放入线索池 '''
        self.find_element(self.batch_put_into_clue_pool_locator).click()

    def clue_pool_button_click(self):
        ''' 进入线索池按钮 '''
        self.find_element(self.clue_pool_button_locator).click()

    def filter_select_choice(self,choice):
        ''' 筛选条件下拉框 '''
        self.select_choice(self.filter_select_locator).select_by_visible_text(choice)

    def clue_search_send(self, keyword):
        ''' 输入线索关键字 '''
        self.find_element(self.clue_search_send_locator).send_keys(keyword)

    def clue_search_button_click(self):
        ''' 线索搜索按钮 '''
        self.find_element(self.clue_search_button_locator).click()

    def add_clue_button_click(self):
        ''' 点击添加线索按钮 '''
        self.find_element(self.add_clue_button_locator).click()



