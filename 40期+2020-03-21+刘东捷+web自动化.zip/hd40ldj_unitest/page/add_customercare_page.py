from page.base_page import BasePage
from selenium.webdriver.common.by import By

class AddCustomerCarePage(BasePage):
    caring_theme_locator = (By.ID,'name')
    care_time_locator = (By.ID,'care_time')
    save_button_locator = (By.XPATH,'/html/body/div[5]/div[2]/div/form/table/tfoot/tr/td[2]/input[1]')

    def send_caring_theme(self,theme):
        ''' 输入关怀主题 '''
        self.find_element(self.caring_theme_locator).send_keys(theme)

    def send_care_time(self,time):
        ''' 输入关怀时间 '''
        self.find_element(self.care_time_locator).send_keys(time)

    def save_button_click(self):
        ''' 保存客户按钮 '''
        self.find_element(self.save_button_locator).click()

