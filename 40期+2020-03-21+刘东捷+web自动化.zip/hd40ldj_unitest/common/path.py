from pathlib import Path

BASE_PATH = Path(__file__).absolute().parent.parent
p = Path(BASE_PATH)
CASE_PATH = p.joinpath("cases")
DATA_PATH = p.joinpath("datas")
COMMON_PATH = p.joinpath("common")
PAGE_PATH = p.joinpath("page")
LOG_PATH = p.joinpath("log")
HOST = "http://192.168.0.102"
CLUE_PATH = HOST+"/crm/index.php?m=leads"
CUSTOMER_PATH = HOST+"/crm/index.php?m=customer"
CUSTOMER_CONTACTS_PATH = HOST+"/crm/index.php?m=contacts&a=index"
CUSTOMERCARE_PATH = HOST+"/crm/index.php?m=customer&a=cares"
CRM_PATH = HOST+"/crm"





