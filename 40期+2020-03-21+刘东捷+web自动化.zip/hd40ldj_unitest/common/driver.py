from selenium import webdriver

def chrome():
    driver = webdriver.Chrome()
    # driver.implicitly_wait(10)
    # driver.maximize_window()
    return driver