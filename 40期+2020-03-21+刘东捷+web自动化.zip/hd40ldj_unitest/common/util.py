import csv  	#引入csv包
import os
import xlrd
from common.path import *

def get_data_from_csv(file):
    fileaname = DATA_PATH.joinpath(file)
    with open(fileaname, "r", encoding="utf-8") as f:
        data = csv.reader(f)
        lst = []
        for user in data:
            lst.append(tuple(user))
        return lst[1:]

def create_cookie(dct,keys=None,default=None):
    ''' 转入web返回的cookies,提取name和value并组成字段. '''
    if keys is None:
        keys = ["name","value"]
    dt = {}
    for key in keys:
        dt[key] = dct.get(key)
    return dt

def get_cookie(filename):
    file = os.path.join(DATA_PATH,filename)
    with open(file,"r+",encoding="utf-8") as f:
        cookies = f.readline()
        return eval(cookies)


# print(get_data_from_csv("user.csv"))
    # file1 = os.path.abspath(filename)
    # print(os.path.abspath(filename))
    # with open(filename,"r",encoding="utf-8") as f:
    #     data = csv.reader(f)
    #     lst = []
    #     for user in data:
    #          lst.append(tuple(user))
    #     return lst[1:]

# def get_data_from_txt():
#     filename = r"D:\pythongc\hd40ldj_unitest\datas\test.txt"
#     with open(filename,"r",encoding="utf-8") as f:
#         data = f.readline()
#         username,password = tuple(data.split(','))

# def get_data_from_excl():
#     filename = r"D:\pythongc\hd40ldj_unitest\datas\test1.xlsx"
#     data = xlrd.open_workbook(filename)
#     table = data.sheet_by_index(0)
#     return table.row(0)[1].value
# print(get_data_from_excl())